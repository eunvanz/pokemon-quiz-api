#!/bin/bash
# EB build scripts will not install using npm if node_modules folder exists
mkdir node_modules