#!/bin/bash
corepack yarn